let cur=0,playing=false,timer=null,counted=new Set();
const $=q=>document.querySelector(q);
const camera=$('#camera'),planwrap=$('#planwrap'),plandim=$('#plandim'),info=$('#infocard');
const dots=$('#dots');
scenes.forEach((s,i)=>{const d=document.createElement('div');d.className='dot';d.onclick=()=>go(i);dots.appendChild(d);});
function countUp(ov){
  if(counted.has(ov))return; counted.add(ov);
  document.querySelectorAll('#'+ov+' [data-count]').forEach(el=>{
    const target=+el.dataset.count, em=el.querySelector('em');
    const suffix=em?em.outerHTML:''; const t0=performance.now(), dur=1600;
    function step(t){const p=Math.min(1,(t-t0)/dur);
      el.innerHTML=Math.round(target*(1-Math.pow(1-p,3)))+suffix;
      if(p<1)requestAnimationFrame(step);}
    requestAnimationFrame(step);});
}
function setInfo(s){
  if(s.info){
    info.querySelector('h3').textContent=s.info.t;
    info.querySelector('.en').textContent=s.info.e;
    const ul=info.querySelector('ul'); ul.innerHTML='';
    s.info.li.forEach(t=>{const li=document.createElement('li');li.textContent=t;ul.appendChild(li);});
    if(s.info.star){const li=document.createElement('li');li.className='star';li.textContent=s.info.star;ul.appendChild(li);}
    info.classList.remove('on'); void info.offsetWidth; info.classList.add('on');
  } else info.classList.remove('on');
}
function go(i){
  cur=(i+scenes.length)%scenes.length;
  const s=scenes[cur];
  document.querySelectorAll('.overlay').forEach(o=>o.classList.remove('on'));
  planwrap.className=''; void planwrap.offsetWidth;
  if(s.ov){ $('#'+s.ov).classList.add('on'); planwrap.style.opacity=0;
    if(s.count)setTimeout(()=>countUp(s.ov),500); }
  else{
    planwrap.style.opacity=1;
    (s.cls||'').split(' ').forEach(c=>{if(c)planwrap.classList.add(c);});
    plandim.style.opacity=((s.cls||'').includes('s5')||(s.cls||'').includes('s6'))?0.42:0;
  }
  camera.style.transform=s.cam||'translate(0,0) scale(1)';
  setInfo(s);
  const mm=$('#minimap');
  if(s.mini){mm.classList.add('on');const p=$('#mpin');p.style.left=s.mini[0]+'%';p.style.top=s.mini[1]+'%';}
  else mm.classList.remove('on');
  $('#scname').textContent=s.name;
  const sub=$('#subtitle');sub.classList.remove('flip');void sub.offsetWidth;sub.classList.add('flip');
  sub.querySelector('.zh').textContent=s.zh;sub.querySelector('.en').textContent=s.en;
  document.querySelectorAll('.dot').forEach((d,j)=>d.classList.toggle('on',j===cur));
  if(playing){clearTimeout(timer);timer=setTimeout(()=>go(cur+1),s.dur);}
}
function setPlay(p){playing=p;$('#btnPlay').textContent=p?'❚❚ 暂停':'▶ 自动播放';
  clearTimeout(timer);if(p)timer=setTimeout(()=>go(cur+1),scenes[cur].dur);}
$('#btnNext').onclick=()=>go(cur+1);$('#btnPrev').onclick=()=>go(cur-1);
$('#btnPlay').onclick=()=>setPlay(!playing);
document.addEventListener('keydown',e=>{
  if(editing)return;
  if(e.key==='ArrowRight')go(cur+1);else if(e.key==='ArrowLeft')go(cur-1);
  else if(e.key===' '){e.preventDefault();setPlay(!playing);}});
// ============ 编辑模式 ============
let editing=false, pickTarget=null;
const EDITSEL='.overlay h1,.overlay .sub2,.overlay .meta,.overlay .eyebrow,.overlay .conf,.overlay .card h3,.overlay .card p,.overlay .tnode h3,.overlay .tnode p,.overlay .chip2,.overlay .stat span,.overlay .trow div,#subtitle .zh,#subtitle .en,#infocard h3,#infocard .en,#infocard li';
function toggleEdit(){
  editing=!editing; document.body.classList.toggle('editing',editing);
  if(editing) setPlay(false);
  document.querySelectorAll(EDITSEL).forEach(el=>el.contentEditable=editing?'true':'false');
  $('#btnEdit').textContent=editing?'✓ 完成编辑':'✎ 编辑';
}
$('#btnEdit').onclick=toggleEdit;
// 字幕/说明卡的修改写回 scenes 数据
$('#subtitle').addEventListener('input',()=>{
  scenes[cur].zh=$('#subtitle .zh').innerText.trim();
  scenes[cur].en=$('#subtitle .en').innerText.trim();});
$('#infocard').addEventListener('input',()=>{
  const s=scenes[cur]; if(!s.info)return;
  s.info.t=$('#infocard h3').innerText.trim();
  s.info.e=$('#infocard .en').innerText.trim();
  const lis=[...document.querySelectorAll('#infocard li')];
  s.info.li=lis.filter(l=>!l.classList.contains('star')).map(l=>l.innerText.trim());
  const st=lis.find(l=>l.classList.contains('star'));
  if(st)s.info.star=st.innerText.trim();});
// 点击图片替换
document.addEventListener('click',e=>{
  if(!editing)return;
  if(e.target.closest('#ctrl,#dots,#editbar,#infocard,#subtitle'))return;
  let t=null;
  if(e.target.classList&&e.target.classList.contains('bgveil')) t=e.target.parentNode.querySelector('.bgpic');
  else if(e.target.classList&&e.target.classList.contains('bgpic')) t=e.target;
  else if(e.target.tagName==='IMG') t=e.target;
  if(t){pickTarget=t;$('#imgpick').click();e.preventDefault();}
});
$('#imgpick').onchange=e=>{
  const f=e.target.files[0]; if(!f||!pickTarget)return;
  const r=new FileReader();
  r.onload=()=>{ if(pickTarget.classList.contains('bgpic')) pickTarget.style.backgroundImage='url('+r.result+')';
    else pickTarget.src=r.result; pickTarget=null; };
  r.readAsDataURL(f); e.target.value='';};
// 导出为新的单文件
$('#btnExport').onclick=()=>{
  const clone=document.documentElement.cloneNode(true);
  const sd=clone.querySelector('#scenesData');
  sd.removeAttribute('src');
  sd.textContent='const scenes='+JSON.stringify(scenes,null,1)+';';
  clone.querySelectorAll('[contenteditable]').forEach(el=>el.removeAttribute('contenteditable'));
  const bd=clone.querySelector('body'); bd.classList.remove('editing');
  const html='<!DOCTYPE html>'+clone.outerHTML;
  const blob=new Blob([html],{type:'text/html;charset=utf-8'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob);
  a.download='BeyondTheHall_修改版_'+new Date().toISOString().slice(0,10)+'.html'; a.click();
};
go(0);
