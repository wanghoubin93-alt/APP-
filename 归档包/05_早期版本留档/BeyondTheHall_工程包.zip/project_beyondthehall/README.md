# Beyond the Hall · 动态投标汇报（开发版工程）

双击 `index.html` 即可本地预览（无需服务器、无需联网）。
推荐用 VS Code 打开本文件夹；装 Live Server 插件可保存即刷新。

## 目录结构
```
├─ index.html            页面骨架 + 平面图SVG叠加层（动线/分区坐标在这里）
├─ css/style.css         全部样式（配色变量在 :root，品牌蓝 --logo / 传播蓝 --sky）
├─ js/scenes.js          ★ 内容配置：幕次顺序、字幕、镜头、说明卡 —— 日常编辑只改这个
├─ js/app.js             演示引擎（切幕/自动播放/数字滚动），一般不用动
├─ assets/               平面图与各场景图片（jpg）
├─ build_single_file.py  一键打包回“单文件交付版”（需要本机装 Python 3）
└─ dist/                 打包输出目录
```

## 最常见的编辑（全部在 js/scenes.js）
每一幕是 scenes 数组里的一个对象：
```js
{ov:'ov9',                 // 用哪个全屏页（对应 index.html 里 id=ov9 的 overlay）；平面幕填 null
 name:'08 / 时间长廊',      // 右上角幕名
 dur:7500,                 // 自动播放停留毫秒数
 cam:'translate(-71%,-5%) scale(1.9)',  // 平面幕的镜头：translate(左右%,上下%) scale(放大倍数)
 info:{t:'A · 前厅展示区', e:'英文小标', li:['要点1','要点2'], star:'★ 橙色强调行'},
 zh:'底部中文字幕（=配音词）', en:'底部英文小字'}
```
- 调顺序：直接移动对象在数组中的位置
- 删一幕：删掉整个对象；加一幕：复制一个改内容
- 镜头微调：scale 控制放大，translate 第一个值负=画面往左看、正=往右看

## 换图片
把新图放进 assets/ 并在 index.html 里改对应 url(assets/xxx.jpg)。
建议宽度 ≤1280px、JPG 质量 75 左右，控制体积。

## 改平面图叠加层（动线/分区色块）
在 index.html 的 <svg> 里：`#flow` 是动线路径，`.zone` 是分区形状，
坐标基于 viewBox 0 0 2000 715（对应 assets/plan.jpg 的像素比例）。

## 交付
编辑满意后运行：`python build_single_file.py`
dist/ 里生成可直接发给评审的单文件版（图片已内嵌，双击即放）。
