# -*- coding: utf-8 -*-
"""一键打包：把工程合并回单文件交付版（图片转base64内嵌）。"""
import base64, re, os
h=open('index.html',encoding='utf-8').read()
css=open('css/style.css',encoding='utf-8').read()
h=h.replace('<link rel="stylesheet" href="css/style.css">','<style>\n'+css+'\n</style>')
h=h.replace('<script id="scenesData" src="js/scenes.js"></script>',
  '<script id="scenesData">\n'+open('js/scenes.js',encoding='utf-8').read()+'\n</script>')
h=h.replace('<script src="js/app.js"></script>',
  '<script>\n'+open('js/app.js',encoding='utf-8').read()+'\n</script>')
def inline(m):
    p=m.group(1)
    mime='image/svg+xml' if p.endswith('.svg') else 'image/jpeg'
    return 'data:'+mime+';base64,'+base64.b64encode(open(p,'rb').read()).decode()
h=re.sub(r'(assets/[\w\-]+\.(?:jpg|svg))',inline,h)
os.makedirs('dist',exist_ok=True)
out='dist/BeyondTheHall_动态投标汇报_单文件版.html'
open(out,'w',encoding='utf-8').write(h)
print('OK ->',out,len(h)//1024,'KB')
